# Contributing to Weather Application

Thank you for your interest in contributing to the Weather Application project!

## Getting Started

1. Fork the repository on GitHub
2. Clone your fork locally:
```bash
git clone https://github.com/your-username/weather-application.git
cd weather-application
```

## Development Setup

### Python Development
```bash
# Install dependencies
pip install requests

# Run tests
python weather_app.py "London"
```

### Java Development
```bash
# Install dependencies and compile
mvn clean compile dependency:copy-dependencies

# Run tests
mvn exec:java -Dexec.mainClass="WeatherApp" -Dexec.args="London"
```

## Making Changes

1. Create a new branch for your feature:
```bash
git checkout -b feature/your-feature-name
```

2. Make your changes
3. Test both Python and Java implementations
4. Commit your changes with clear messages:
```bash
git commit -m "Add feature: description of what you added"
```

## Testing

Before submitting changes, please test:

- Both Python and Java versions work correctly
- Error handling works (try invalid city names)
- Different cities return correct data
- Code follows existing style patterns

## Submitting Changes

1. Push your branch to your fork:
```bash
git push origin feature/your-feature-name
```

2. Create a Pull Request on GitHub
3. Describe your changes clearly in the PR description

## Code Style

### Python
- Follow PEP 8 style guidelines
- Use meaningful variable names
- Include docstrings for functions
- Handle exceptions appropriately

### Java
- Follow Java naming conventions
- Use proper indentation (4 spaces)
- Include JavaDoc comments for methods
- Handle exceptions with try-catch blocks

## Issue Reporting

When reporting issues:
- Include steps to reproduce
- Specify which version (Python/Java)
- Include error messages if any
- Mention your operating system

## Feature Requests

We welcome feature requests! Please:
- Check existing issues first
- Describe the feature clearly
- Explain why it would be useful
- Consider implementing it yourself

## Questions?

If you have questions about contributing, feel free to open an issue with the "question" label.