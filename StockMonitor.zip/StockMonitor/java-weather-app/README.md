# Java Weather Application

A command-line weather application that fetches and displays current weather data from OpenWeatherMap API using Java.

## Features

- Real-time weather data from OpenWeatherMap API
- Support for any city worldwide
- Displays temperature, humidity, pressure, weather conditions, and wind speed
- Comprehensive error handling for network issues and invalid inputs
- Uses Apache HTTP Client and Gson for reliable API communication
- Cross-platform compatibility

## Requirements

- Java 21 or higher
- Maven 3.6 or higher
- Internet connection

## Dependencies

- Apache HTTP Components (httpclient 4.5.13)
- Google Gson (2.10.1)

## Installation & Setup

1. **Clone or download the project files**

2. **Compile the application:**
```bash
mvn clean compile dependency:copy-dependencies
```

## Usage

### Run with default city (London):
```bash
mvn exec:java -Dexec.mainClass="WeatherApp"
```

### Run with specific city:
```bash
mvn exec:java -Dexec.mainClass="WeatherApp" -Dexec.args="Tokyo"
mvn exec:java -Dexec.mainClass="WeatherApp" -Dexec.args="New York"
```

## Sample Output

```
Fetching weather data for London...

Weather Information for London:
========================================
Temperature: 20.2 °C
Humidity: 72%
Pressure: 1020 hPa
Weather: Few Clouds
Wind Speed: 1.03 m/s
```

## API Configuration

The application uses OpenWeatherMap API. You can:

1. **Use the default API key** (included for testing)
2. **Set your own API key** via environment variable:
```bash
export OPENWEATHER_API_KEY=your_api_key_here
```

Get your free API key at: https://openweathermap.org/api

## Project Structure

```
java-weather-app/
├── src/main/java/WeatherApp.java    # Main application
├── pom.xml                          # Maven configuration
├── README.md                        # This file
├── LICENSE                          # MIT License
└── .gitignore                       # Git ignore rules
```

## Error Handling

The application handles:
- Invalid API keys (401 error)
- City not found (404 error)
- Network connection issues
- API rate limits (429 error)
- Invalid response formats
- Timeout errors

## Building a JAR File

To create a standalone JAR file:

```bash
mvn clean compile assembly:single
java -jar target/weather-app-1.0.0-jar-with-dependencies.jar [city_name]
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Technical Details

- **HTTP Client**: Apache HTTP Components for reliable API calls
- **JSON Parsing**: Google Gson for robust JSON handling
- **Error Handling**: Comprehensive exception handling for all failure scenarios
- **URL Encoding**: Proper encoding for international city names
- **Timeout Handling**: Built-in request timeouts for better user experience