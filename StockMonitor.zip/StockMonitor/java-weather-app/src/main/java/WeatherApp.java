import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * Weather Application - Java Implementation
 * Fetches and displays current weather data from OpenWeatherMap API
 * 
 * Features:
 * - Real-time weather data retrieval
 * - Support for any city worldwide
 * - Comprehensive error handling
 * - Clean, formatted output
 * 
 * Usage:
 * mvn exec:java -Dexec.mainClass="WeatherApp" -Dexec.args="CityName"
 * 
 * @author Weather App
 * @version 1.0.0
 */
public class WeatherApp {

    // Get API key from environment variable with fallback for testing
    private static final String API_KEY = System.getenv("OPENWEATHER_API_KEY") != null ? 
                                         System.getenv("OPENWEATHER_API_KEY") : 
                                         "e66a69a483cf26c42e05fae9eff4cf2c";
    
    // OpenWeatherMap API endpoint
    private static final String API_BASE_URL = "https://api.openweathermap.org/data/2.5/weather";

    /**
     * Main entry point of the application
     * 
     * @param args Command line arguments - first argument is city name (optional)
     */
    public static void main(String[] args) {
        // Use city from arguments or default to London
        String city = (args.length > 0) ? args[0] : "London";
        
        System.out.println("Fetching weather data for " + city + "...");
        System.out.println();
        
        WeatherApp app = new WeatherApp();
        app.fetchAndDisplayWeather(city);
    }
    
    /**
     * Fetches weather data from OpenWeatherMap API and displays it
     * 
     * @param city The name of the city to get weather for
     */
    private void fetchAndDisplayWeather(String city) {
        try {
            // URL encode the city name to handle special characters and spaces
            String encodedCity = URLEncoder.encode(city, StandardCharsets.UTF_8);
            String apiUrl = API_BASE_URL + "?q=" + encodedCity + "&appid=" + API_KEY + "&units=metric";

            // Create HTTP client and make the API request
            try (CloseableHttpClient httpClient = HttpClients.createDefault();
                 CloseableHttpResponse response = httpClient.execute(new HttpGet(apiUrl))) {

                int statusCode = response.getStatusLine().getStatusCode();

                // Handle different HTTP status codes
                if (statusCode != 200) {
                    handleApiError(statusCode, city);
                    return;
                }

                // Extract response body
                HttpEntity entity = response.getEntity();
                if (entity == null) {
                    System.out.println("Error: Empty response from weather service.");
                    return;
                }

                // Parse JSON response and display weather data
                String responseString = EntityUtils.toString(entity);
                JsonObject jsonResponse = JsonParser.parseString(responseString).getAsJsonObject();
                displayWeatherData(jsonResponse, city);

            } catch (IOException e) {
                System.err.println("Error: Network connection failed.");
                System.err.println("Please check your internet connection and try again.");
                if (e.getMessage().contains("timeout")) {
                    System.err.println("The request timed out. The weather service might be slow.");
                }
            }
            
        } catch (Exception e) {
            System.err.println("Unexpected error occurred: " + e.getMessage());
            System.err.println("Please try again or contact support if the problem persists.");
        }
    }
    
    /**
     * Handles API error responses with user-friendly messages
     * 
     * @param statusCode HTTP status code returned by the API
     * @param city The city name that caused the error
     */
    private void handleApiError(int statusCode, String city) {
        switch (statusCode) {
            case 401:
                System.out.println("Error: Invalid API key.");
                System.out.println("Please check your OpenWeatherMap API key configuration.");
                System.out.println("You can set it using: export OPENWEATHER_API_KEY=your_key");
                break;
            case 404:
                System.out.println("Error: City '" + city + "' not found.");
                System.out.println("Please check the spelling and try again.");
                System.out.println("Make sure to use the correct city name format.");
                break;
            case 429:
                System.out.println("Error: API rate limit exceeded.");
                System.out.println("Please wait a moment and try again.");
                break;
            case 500:
            case 502:
            case 503:
                System.out.println("Error: Weather service is temporarily unavailable.");
                System.out.println("Please try again in a few minutes.");
                break;
            default:
                System.out.println("Error: Failed to retrieve weather data.");
                System.out.println("HTTP Status Code: " + statusCode);
                System.out.println("Please try again later.");
        }
    }
    
    /**
     * Parses and displays weather data in a formatted way
     * 
     * @param jsonResponse JSON response from the OpenWeatherMap API
     * @param city The city name for display purposes
     */
    private void displayWeatherData(JsonObject jsonResponse, String city) {
        try {
            // Safely extract weather data with null checks
            JsonObject main = jsonResponse.has("main") ? jsonResponse.getAsJsonObject("main") : new JsonObject();
            JsonObject wind = jsonResponse.has("wind") ? jsonResponse.getAsJsonObject("wind") : new JsonObject();
            JsonObject weather = jsonResponse.has("weather") && jsonResponse.getAsJsonArray("weather").size() > 0 ?
                                jsonResponse.getAsJsonArray("weather").get(0).getAsJsonObject() : new JsonObject();

            // Extract individual weather parameters with safe handling
            double temperature = main.has("temp") ? main.get("temp").getAsDouble() : Double.NaN;
            int humidity = main.has("humidity") ? main.get("humidity").getAsInt() : -1;
            int pressure = main.has("pressure") ? main.get("pressure").getAsInt() : -1;
            double windSpeed = wind.has("speed") ? wind.get("speed").getAsDouble() : Double.NaN;
            String description = weather.has("description") ? weather.get("description").getAsString() : "N/A";
            
            // Capitalize the weather description for better presentation
            if (!description.equals("N/A")) {
                description = capitalizeWords(description);
            }

            // Display formatted weather information
            System.out.println("Weather Information for " + city + ":");
            System.out.println("========================================");
            
            // Temperature
            if (!Double.isNaN(temperature)) {
                System.out.printf("Temperature: %.1f °C%n", temperature);
            } else {
                System.out.println("Temperature: N/A");
            }
            
            // Humidity
            if (humidity != -1) {
                System.out.println("Humidity: " + humidity + "%");
            } else {
                System.out.println("Humidity: N/A");
            }
            
            // Pressure
            if (pressure != -1) {
                System.out.println("Pressure: " + pressure + " hPa");
            } else {
                System.out.println("Pressure: N/A");
            }
            
            // Weather description
            System.out.println("Weather: " + description);
            
            // Wind speed
            if (!Double.isNaN(windSpeed)) {
                System.out.println("Wind Speed: " + windSpeed + " m/s");
            } else {
                System.out.println("Wind Speed: N/A");
            }

        } catch (Exception e) {
            System.err.println("Error parsing weather data: " + e.getMessage());
            System.err.println("The weather service returned an unexpected response format.");
        }
    }
    
    /**
     * Capitalizes the first letter of each word in a string
     * 
     * @param text The text to capitalize
     * @return Capitalized text
     */
    private String capitalizeWords(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        
        String[] words = text.split(" ");
        StringBuilder result = new StringBuilder();
        
        for (int i = 0; i < words.length; i++) {
            if (i > 0) {
                result.append(" ");
            }
            String word = words[i];
            if (word.length() > 0) {
                result.append(Character.toUpperCase(word.charAt(0)));
                if (word.length() > 1) {
                    result.append(word.substring(1).toLowerCase());
                }
            }
        }
        
        return result.toString();
    }
}