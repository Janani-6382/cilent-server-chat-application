#!/bin/bash

# Chat Application Demo Script
# This script demonstrates how to run the complete chat application

echo "==================================="
echo "    Java Chat Application Demo"
echo "==================================="

# Check if Java is available
if ! command -v java &> /dev/null; then
    echo "Error: Java is not installed or not in PATH"
    exit 1
fi

if ! command -v javac &> /dev/null; then
    echo "Error: Java compiler (javac) is not installed or not in PATH"
    exit 1
fi

echo "Java version:"
java -version
echo ""

# Compile the application
echo "Compiling chat application..."
javac *.java

if [ $? -ne 0 ]; then
    echo "Compilation failed!"
    exit 1
fi

echo "Compilation successful!"
echo ""

echo "==================================="
echo "How to run the chat application:"
echo "==================================="
echo ""
echo "1. Start the server (in one terminal):"
echo "   java ChatServer"
echo ""
echo "2. Start GUI clients (in separate terminals):"
echo "   java ChatClient"
echo ""
echo "3. Or start text-based test client:"
echo "   java TestChat"
echo ""
echo "==================================="
echo "Features:"
echo "- Multiple clients can connect simultaneously"
echo "- Real-time messaging between all users"
echo "- GUI client with Swing interface"
echo "- Command-line test client available"
echo "- Proper connection handling and cleanup"
echo "- Join/leave notifications"
echo "- Built-in chat commands (/help, /users, /quit)"
echo "==================================="

# Optional: Start server automatically
read -p "Do you want to start the server now? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Starting chat server..."
    java ChatServer
fi