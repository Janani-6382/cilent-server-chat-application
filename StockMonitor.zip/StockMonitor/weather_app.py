#!/usr/bin/env python3
"""
Weather Application - Command Line Interface
Fetches and displays current weather data from OpenWeatherMap API
"""

import os
import sys
import json
import requests
from urllib.parse import quote

class WeatherApp:
    def __init__(self):
        # Get API key from environment variable with fallback
        self.api_key = os.getenv("OPENWEATHER_API_KEY", "e66a69a483cf26c42e05fae9eff4cf2c")
        self.base_url = "https://api.openweathermap.org/data/2.5/weather"
    
    def get_weather_data(self, city):
        """
        Fetch weather data from OpenWeatherMap API
        
        Args:
            city (str): City name to get weather for
            
        Returns:
            dict: Weather data or None if request fails
        """
        try:
            # URL encode the city name to handle special characters
            encoded_city = quote(city)
            
            # Construct the API URL with parameters
            params = {
                'q': city,
                'appid': self.api_key,
                'units': 'metric'  # Use metric units (Celsius, m/s, etc.)
            }
            
            # Make the HTTP request
            response = requests.get(self.base_url, params=params, timeout=10)
            
            # Check if request was successful
            if response.status_code != 200:
                if response.status_code == 401:
                    print("Error: Invalid API key. Please check your OpenWeatherMap API key.")
                elif response.status_code == 404:
                    print(f"Error: City '{city}' not found. Please check the city name.")
                else:
                    print(f"Error: Failed to retrieve weather data. HTTP Status Code: {response.status_code}")
                return None
            
            # Parse JSON response
            weather_data = response.json()
            return weather_data
            
        except requests.exceptions.Timeout:
            print("Error: Request timed out. Please check your internet connection.")
            return None
        except requests.exceptions.ConnectionError:
            print("Error: Connection error. Please check your internet connection.")
            return None
        except requests.exceptions.RequestException as e:
            print(f"Error: Network request failed - {str(e)}")
            return None
        except json.JSONDecodeError:
            print("Error: Invalid response format from weather service.")
            return None
        except Exception as e:
            print(f"Unexpected error: {str(e)}")
            return None
    
    def display_weather(self, weather_data, city):
        """
        Display weather information in a formatted way
        
        Args:
            weather_data (dict): Weather data from API
            city (str): City name
        """
        try:
            # Extract weather information safely
            main = weather_data.get('main', {})
            wind = weather_data.get('wind', {})
            weather = weather_data.get('weather', [{}])[0] if weather_data.get('weather') else {}
            
            # Get individual weather parameters with fallbacks
            temperature = main.get('temp', 'N/A')
            humidity = main.get('humidity', 'N/A')
            pressure = main.get('pressure', 'N/A')
            wind_speed = wind.get('speed', 'N/A')
            description = weather.get('description', 'N/A')
            
            # Capitalize first letter of each word in description
            if description != 'N/A':
                description = description.title()
            
            # Display formatted weather information
            print(f"Weather Information for {city}:")
            print("=" * 40)
            
            if temperature != 'N/A':
                print(f"Temperature: {temperature:.1f} °C")
            else:
                print("Temperature: N/A")
                
            if humidity != 'N/A':
                print(f"Humidity: {humidity}%")
            else:
                print("Humidity: N/A")
                
            if pressure != 'N/A':
                print(f"Pressure: {pressure} hPa")
            else:
                print("Pressure: N/A")
                
            print(f"Weather: {description}")
            
            if wind_speed != 'N/A':
                print(f"Wind Speed: {wind_speed} m/s")
            else:
                print("Wind Speed: N/A")
                
        except Exception as e:
            print(f"Error displaying weather data: {str(e)}")
    
    def run(self):
        """
        Main application entry point
        """
        # Get city from command line arguments or use default
        if len(sys.argv) > 1:
            city = sys.argv[1]
        else:
            city = "London"
        
        print(f"Fetching weather data for {city}...")
        print()
        
        # Fetch weather data
        weather_data = self.get_weather_data(city)
        
        if weather_data:
            # Display the weather information
            self.display_weather(weather_data, city)
        else:
            print("Unable to retrieve weather information.")
            sys.exit(1)

def main():
    """
    Application entry point
    """
    app = WeatherApp()
    app.run()

if __name__ == "__main__":
    main()
