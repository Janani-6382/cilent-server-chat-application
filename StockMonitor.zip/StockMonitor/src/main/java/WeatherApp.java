import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * Weather Application - Java Implementation
 * Fetches and displays current weather data from OpenWeatherMap API
 */
public class WeatherApp {

    // Get API key from environment variable with fallback
    private static final String API_KEY = System.getenv("OPENWEATHER_API_KEY") != null ? 
                                         System.getenv("OPENWEATHER_API_KEY") : 
                                         "e66a69a483cf26c42e05fae9eff4cf2c";

    public static void main(String[] args) {
        // Use city from arguments or default to London
        String city = (args.length > 0) ? args[0] : "London";
        
        System.out.println("Fetching weather data for " + city + "...");
        System.out.println();
        
        WeatherApp app = new WeatherApp();
        app.fetchAndDisplayWeather(city);
    }
    
    private void fetchAndDisplayWeather(String city) {
        try {
            String encodedCity = URLEncoder.encode(city, StandardCharsets.UTF_8);
            String apiUrl = "https://api.openweathermap.org/data/2.5/weather?q=" +
                           encodedCity + "&appid=" + API_KEY + "&units=metric";

            // Create the HTTP client and make request
            try (CloseableHttpClient httpClient = HttpClients.createDefault();
                 CloseableHttpResponse response = httpClient.execute(new HttpGet(apiUrl))) {

                int statusCode = response.getStatusLine().getStatusCode();

                if (statusCode != 200) {
                    handleApiError(statusCode, city);
                    return;
                }

                HttpEntity entity = response.getEntity();
                if (entity == null) {
                    System.out.println("Error: Empty response from weather service.");
                    return;
                }

                String responseString = EntityUtils.toString(entity);
                JsonObject jsonResponse = JsonParser.parseString(responseString).getAsJsonObject();

                displayWeatherData(jsonResponse, city);

            } catch (IOException e) {
                System.err.println("Error: Network connection failed.");
                System.err.println("Please check your internet connection and try again.");
                e.printStackTrace();
            }
            
        } catch (Exception e) {
            System.err.println("Unexpected error occurred:");
            e.printStackTrace();
        }
    }
    
    private void handleApiError(int statusCode, String city) {
        switch (statusCode) {
            case 401:
                System.out.println("Error: Invalid API key. Please check your OpenWeatherMap API key.");
                break;
            case 404:
                System.out.println("Error: City '" + city + "' not found. Please check the city name.");
                break;
            case 429:
                System.out.println("Error: API rate limit exceeded. Please try again later.");
                break;
            default:
                System.out.println("Error: Failed to retrieve weather data. HTTP Status Code: " + statusCode);
        }
    }
    
    private void displayWeatherData(JsonObject jsonResponse, String city) {
        try {
            // Safely extract and display weather data
            JsonObject main = jsonResponse.has("main") ? jsonResponse.getAsJsonObject("main") : new JsonObject();
            JsonObject wind = jsonResponse.has("wind") ? jsonResponse.getAsJsonObject("wind") : new JsonObject();
            JsonObject weather = jsonResponse.has("weather") && jsonResponse.getAsJsonArray("weather").size() > 0 ?
                                jsonResponse.getAsJsonArray("weather").get(0).getAsJsonObject() : new JsonObject();

            // Extract values with safe handling
            double temperature = main.has("temp") ? main.get("temp").getAsDouble() : Double.NaN;
            int humidity = main.has("humidity") ? main.get("humidity").getAsInt() : -1;
            int pressure = main.has("pressure") ? main.get("pressure").getAsInt() : -1;
            double windSpeed = wind.has("speed") ? wind.get("speed").getAsDouble() : Double.NaN;
            String description = weather.has("description") ? weather.get("description").getAsString() : "N/A";
            
            // Capitalize the description
            if (!description.equals("N/A")) {
                description = capitalizeWords(description);
            }

            // Display formatted weather information
            System.out.println("Weather Information for " + city + ":");
            System.out.println("========================================");
            
            if (!Double.isNaN(temperature)) {
                System.out.printf("Temperature: %.1f °C%n", temperature);
            } else {
                System.out.println("Temperature: N/A");
            }
            
            if (humidity != -1) {
                System.out.println("Humidity: " + humidity + "%");
            } else {
                System.out.println("Humidity: N/A");
            }
            
            if (pressure != -1) {
                System.out.println("Pressure: " + pressure + " hPa");
            } else {
                System.out.println("Pressure: N/A");
            }
            
            System.out.println("Weather: " + description);
            
            if (!Double.isNaN(windSpeed)) {
                System.out.println("Wind Speed: " + windSpeed + " m/s");
            } else {
                System.out.println("Wind Speed: N/A");
            }

        } catch (Exception e) {
            System.err.println("Error parsing weather data: " + e.getMessage());
        }
    }
    
    private String capitalizeWords(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        
        String[] words = text.split(" ");
        StringBuilder result = new StringBuilder();
        
        for (int i = 0; i < words.length; i++) {
            if (i > 0) {
                result.append(" ");
            }
            String word = words[i];
            if (word.length() > 0) {
                result.append(Character.toUpperCase(word.charAt(0)));
                if (word.length() > 1) {
                    result.append(word.substring(1).toLowerCase());
                }
            }
        }
        
        return result.toString();
    }
}