# Weather Application

## Overview

This is a command-line weather application that fetches current weather data from the OpenWeatherMap API. The repository contains both Python and Java implementations of the same core functionality, providing weather information for specified cities with temperature, humidity, wind speed, and weather conditions.

## Recent Changes (July 25, 2025)

✓ Added Java implementation of weather application
✓ Created Maven project structure with dependencies (Apache HTTP Client, Gson)
✓ Implemented Java version with same API functionality as Python
✓ Set up Java workflow for easy execution
✓ Both Python and Java versions successfully fetch real weather data

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a simple client-server architecture pattern:

- **Client**: Command-line interface that accepts user input (city names)
- **API Integration**: Direct HTTP requests to OpenWeatherMap REST API
- **Data Processing**: JSON parsing and formatting for display
- **Output**: Formatted weather information displayed in the terminal

The architecture prioritizes simplicity and direct API communication without intermediate data storage or complex processing layers.

## Key Components

### Core Application Class
- **WeatherApp**: Main application class handling API communication and data processing
- Manages API key configuration through environment variables
- Handles HTTP requests with proper error handling and timeouts
- Processes JSON responses and formats output for users

### API Integration Layer
- **HTTP Client**: Uses standard HTTP libraries (requests for Python, Apache HTTP for Java)
- **URL Construction**: Dynamic URL building with proper parameter encoding
- **Error Handling**: Comprehensive error handling for network issues, invalid API keys, and city not found scenarios

### Data Processing
- **JSON Parsing**: Native JSON parsing capabilities in both languages
- **Data Extraction**: Selective extraction of relevant weather metrics
- **Unit Conversion**: Uses metric units (Celsius, m/s) for consistency

## Data Flow

1. **Input**: User provides city name via command line arguments or interactive input
2. **URL Construction**: City name is URL-encoded and combined with API endpoint and parameters
3. **API Request**: HTTP GET request sent to OpenWeatherMap API with API key authentication
4. **Response Processing**: JSON response parsed to extract weather data
5. **Output Formatting**: Weather information formatted and displayed to user
6. **Error Handling**: Any errors during the process are caught and user-friendly messages displayed

## External Dependencies

### Third-Party Services
- **OpenWeatherMap API**: Primary weather data source
  - Requires API key for authentication
  - Provides current weather conditions globally
  - Returns data in JSON format

### Libraries and Frameworks

**Python Implementation:**
- `requests`: HTTP client library for API calls
- `json`: Built-in JSON parsing
- `urllib.parse`: URL encoding utilities
- `os`: Environment variable access

**Java Implementation:**
- `Apache HTTP Components`: HTTP client functionality
- `Google Gson`: JSON parsing and manipulation
- `java.net.URLEncoder`: URL encoding utilities

## Deployment Strategy

### Environment Configuration
- **API Key Management**: Uses environment variables with fallback to default key
- **Cross-Platform**: Designed to run on any system with Python 3 or Java runtime

### Execution Model
- **Command-Line Application**: No web server or persistent services required
- **Single Execution**: Each run fetches fresh data and exits
- **Minimal Resource Requirements**: Low memory and CPU usage

### Distribution Options
- **Standalone Scripts**: Can be distributed as single files
- **No Database Required**: Stateless application with no data persistence
- **Container Ready**: Simple containerization possible for both implementations

The application is designed for simplicity and portability, making it easy to deploy across different environments without complex setup requirements.